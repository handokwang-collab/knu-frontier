# 🎨 프롬프트 엔지니어링 워크숍 포트폴리오

> Stable Diffusion AI를 활용한 이미지 생성 실습 결과물

## 👤 수강생 정보

| 항목 | 내용 |
|------|------|
| **이름** | 한도광 |
| **학번** | 20080627 |
| **작성일** | 2026년 01월 23일 |
| **총 작품 수** | 7개 |

---

## 📚 회차별 학습 기록

### 📖 2회차: Zero-shot vs Detail

**학습 기법**: 상세 프롬프팅

#### 작품 1

| 항목 | 내용 |
|------|------|
| **프롬프트** | `a cat` |
| **네거티브** | `-` |
| **생성 시간** | 2026-01-23 05:47:46 |

![작품 1](images/session2_1.png)

> 우선 단순히 a cat만 적었을 때 보다 상세하게 적었을때 주위에 사물이나 건물이 추가되고 분위기가 더 포근해 보이는 효과가 있는 것 같다. 하지만 얼굴 형이나 눈의 모양,위치 등이 오류가 나는것을 보아 아직은 더 보완해야 할 점이 보인다.

#### 작품 2

| 항목 | 내용 |
|------|------|
| **프롬프트** | `a fluffy orange cat sitting on a vintage armchair, warm sunlight streaming through window, photorealistic, highly detailed, 8k resolution` |
| **네거티브** | `-` |
| **생성 시간** | 2026-01-23 05:47:46 |

![작품 2](images/session2_2.png)

> 우선 단순히 a cat만 적었을 때 보다 상세하게 적었을때 주위에 사물이나 건물이 추가되고 분위기가 더 포근해 보이는 효과가 있는 것 같다. 하지만 얼굴 형이나 눈의 모양,위치 등이 오류가 나는것을 보아 아직은 더 보완해야 할 점이 보인다.

---

### 📖 3회차: Persona & Style

**학습 기법**: 스타일 프롬프팅

#### 작품 1

| 항목 | 내용 |
|------|------|
| **프롬프트** | `a car, in the style of Studio Ghibli anime, soft colors, whimsical` |
| **네거티브** | `-` |
| **생성 시간** | 2026-01-23 05:54:36 |

![작품 1](images/session3_1.png)

> 지브리 스타일은 자동차가 결합되어 있는 모습으로 몽환적인 느낌이나 현실적인 느낌이 거의 없지만 사이버펑크는 자동차 그 자체에 초점을 맞추어 도로를 달리고 있는 모습으로 그니마 현실적인 모습을 보여주게 된다. 이로써 AI는 지브리는 상상에 나올 법 한  그림을 많이 그려주고 반 고흐는 별이 빛나는 밤에서 영감을 많이 받았는지 작풍이 많이 비슷하고 사진처럼은 현실적으로 생겼다.

---

### 📖 4회차: Negative Prompting

**학습 기법**: 네거티브 프롬프팅

#### 작품 1

| 항목 | 내용 |
|------|------|
| **프롬프트** | `a beautiful portrait of a young woman, elegant dress, garden background, soft lighting` |
| **네거티브** | `bad hands, extra fingers, mutated hands, poorly drawn face, mutation, deformed, ugly` |
| **생성 시간** | 2026-01-23 06:22:19 |

![작품 1](images/session4_1.png)

> 1~5로 설정하니 사람의 손이나 얼굴이 왜곡되거나 사라지는 현상이 발생하게 되고 7~8은 적당하게 잘 그려주는 것 같다 하지만 얼굴이나 손,발 등 보여주지 않고 그린다는 단점이 있는 것 같지만  현재까지 가장 완성도 높은 그림이라고 평가 할 수 있다 마지막으로 10이상은 손과 발은 정상적으로 그리지만 아직까지 얼굴은 뒤틀려 보인다.

---

### 📖 5회차: Step-back Prompting

**학습 기법**: 추상화 프롬프팅

#### 작품 1

| 항목 | 내용 |
|------|------|
| **프롬프트** | `a person sitting alone on an empty bench, rainy day, view from behind, grey cloudy sky, melancholic atmosphere` |
| **네거티브** | `blurry, low quality, distorted, text, watermark` |
| **생성 시간** | 2026-01-23 06:29:00 |

![작품 1](images/session5_1.png)

> 추상적인 단어인 외로움을 AI는 그냥 어두운 방이나 배경에 사람이 있는 모습을 그려주거나 외로움을 이해하지 못하는 모습을 보여준다. 하지만 사람 자체가 우울하지 않고 배경만 우울한 모습을 관찰 할 수 있다. 하지만 Step-back 프롬프트하게 되면 외로움이라는 것을 생각하고 그에 어울리는 사물이나 배경 사람의 포즈등을 생각하여 만드는 것 같다.

---

### 📖 6회차: Chain of Thought

**학습 기법**: 레이어 빌딩

#### 작품 1

| 항목 | 내용 |
|------|------|
| **프롬프트** | `a robot, play a game, in a jinsu room, warm candlelight,soft air, oil painting style` |
| **네거티브** | `blurry, low quality` |
| **생성 시간** | 2026-01-23 06:35:41 |

![작품 1](images/session6_1.png)

> 우선 레이어 5가 없을때는 막 찍어낸 그림 같았지만 레이어5를 지정 하면 작풍이 바뀌고 내가 설정한 단계별로 AI가 그림을 맞춰준다. 도중에 game이 뭔지 잘못 이해한것 같아 보이기는 했지는 그것 말고는 다 좋았다.

---

### 📖 7회차: 종합 실습

**학습 기법**: 종합

#### 작품 1

| 항목 | 내용 |
|------|------|
| **프롬프트** | `A very cute cat, flying in the sky, Studio Ghibli style, anime, soft colors, highly detailed, sharp focus, 8k resolution` |
| **네거티브** | `blurry, low quality, distorted, ugly, bad anatomy` |
| **생성 시간** | 2026-01-23 06:40:16 |

![작품 1](images/session7_1.png)

> 내가 원하는 것을 입력하면 그게 무엇인지는 인지는 하지만 귀여운게 뭔지 그리고 하늘을 날다라는게 진짜 하늘위인지 높은 나무위 인지 잘 모르는 것 같다.

---

## 🏆 Best 작품

**선택한 작품**: 

**선택 이유**: 

---

## 💡 워크숍 후기



---

## 🛠️ 사용 기술

- Stable Diffusion
- Streamlit
- Google Colab + ngrok

---

<p align="center"><i>🎓 KNU 프롬프트 엔지니어링 워크숍 수료</i></p>
